<?php
session_start();
if ( $_SESSION['login'] )
{
   header("Location: /miolo26/html/index.php?module=portal&acton=main");
}

?>

<?php
require_once '../../../miolo20/classes/miolo.class';

class LoginPersonalizado
{
    public $dbname;
    public $host;
    public $port;
    public $user;
    public $password;
    public $connect;

   function __construct() 
   {

        $MIOLO = MIOLO::getInstance();
        $MIOLO->conf = new MConfigLoader();
        $MIOLO->conf->loadConf();

	    $this->dbname = $MIOLO->getConf('db.admin.name');
        $this->host = $MIOLO->getConf('db.admin.host');
        if (strpos($this->host, ':'))
        {
            $this->host = substr($MIOLO->getConf('db.admin.host'), 0, -5);
        }
	    $this->port = $MIOLO->getConf('db.admin.port');
        $this->user = $MIOLO->getConf('db.admin.user');
        $this->password = $MIOLO->getConf('db.admin.password');

        $string_connect = "host={$this->host} port={$this->port} dbname={$this->dbname} user={$this->user} password={$this->password}";

        $this->connect = pg_connect($string_connect);

        if (!$this->connect)
        {
            echo "Falha na conexão com o banco de dados";
            exit;
        }
   }

    public function obterUnidades()
    {
        $result = pg_query($this->connect, "SELECT unitid,
                                             description
                                        FROM basunit
                                    ORDER BY description");

        $allData = pg_fetch_all($result);

        foreach($allData as $k => $unidade)
        {
            $codigo = $unidade['unitid'];
            $descricao = $unidade['description'];
            $unidades .= "<option value={$codigo}>{$descricao}</option>";
        }

        return $unidades;
    }

    public function verificaMultiUnidade()
    {
        $result = pg_query($this->connect, "SELECT getparameter('BASIC','ATIVAR_MULTIUNIDADE') as value");
        $allData = pg_fetch_all($result);

        return $allData[0]['value'];
    }

    public function obterLogo() {
        $src = "images/logo.png";
        $result = pg_query($this->connect, "SELECT getparameter('PORTAL','IMAGEM_LOGIN_DA_TELA_DO_PORTAL') as value");
        $allData = pg_fetch_all($result);
        if (strlen($allData[0]['value']) > 0)
        {
            $src = $allData[0]['value'];
        }
        return $src;
    }

}

?> 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=no">
<!--
LOGIN FORM
by: Larri Benedetti Pereira
www.solis.com.br
-->

<!--META-->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>SolisGE</title>

<!--STYLESHEETS-->

<link href="css/animate.css" rel="stylesheet">		
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="shortcut icon" href="images/favicon.ico" />
<link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="css/reset.css">
<link rel="stylesheet" href="css/bootstrap.css" />



<!--SCRIPTS-->
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.2.6/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery-2.2.3.js"></script>
<script type="text/javascript" src="js/jquery.mask.min.js"></script>

<!--Slider-in icons-->
<script type="text/javascript">
$(document).ready(function() {
    $(".username").focus(function() {
        $(".user-icon").css("left","-48px");
    });
    $(".username").blur(function() {
        $(".user-icon").css("left","0px");
    });
    
    $(".password").focus(function() {
        $(".pass-icon").css("left","-48px");
    });
    $(".password").blur(function() {
        $(".pass-icon").css("left","0px");
    });
    
    $('#dateBirth').mask('00/00/0000');
    $('#uid2	').mask('000.000.000-00', {reverse: true});
});

    

</script>

</head>
<body>

<div class="logo2">
    
<?php $login = new LoginPersonalizado(); ?>

 <div class="col-md-12 loginscreen animated fadeInDown text-center adm">
        <img class="img img-responsive" src="<?php echo $login->obterLogo(); ?>"  alt="Solis" longdesc="http://www.solis.com.br" />

</div>

</div>
<!--WRAPPER-->
   <?php
        if (isset($_GET['erroAutenticacao']) )
        {
            echo "<p style = 'color: red; text-align: center; font-size: 15px;'>Usu&aacute;rio ou senha inv&aacute;lidos!</p></br>";
        }
?>
<div id="wrapper">
    <!--SLIDE-IN ICONS-->
    <div class="user-icon"></div>
    <div class="pass-icon"></div>
    <!--END SLIDE-IN ICONS-->

<!--LOGIN FORM-->
<div class=" row form text-center" >
                <div class='col-md-12 '>
 
<form name="frm___mainForm" class="login-form" action="/miolo26/html/index.php?module=portal&action=main&event=btnLogin_click&return_to=portal" method="post" >
    <!--H EADER-->
  <div class="header">
    <!--TITLE-->
    <h1> Bem vindo ao portal! </h1>

    <!--END TITLE-->
    <!--DESCRIPTION--><!--END DESCRIPTION--></div>
    <!--END HEADER-->

    
    <!--CONTENT-->
   <div class="content">
   
    

      <input type="text" name="uid" maxlength="50" class="input username" id="uid" placeholder="Usuário">
   
    <!--senha-->
    <input type="password" name="pwd" maxlength="50" class="input password" id = "pwd" placeholder = "Senha" /> 
    <br>
      <a style="margin-left: 5px; color: gray;" href="/miolo20/html/index.php?module=admin&action=forgottenPassword" tabindex=12>Esqueceu a senha?</a>

    <br>
   
    <!--END senha-->
<?php
if ($login->verificaMultiUnidade()=='t')
{?>
    
    <select id="unitId" class="mSelection" name="unitId" required >
    <?php echo $login->obterUnidades() ?>
    </select>
<?php
}
?>
    </div>
    
       <input type="hidden" name = "module" value = "portal">
<input type="hidden" name = "action" value = "main">
<input type="hidden" name = "return_to" value = "https://sagu.faema.edu.br/portal">
<input type="hidden" name = "__mainForm__EVENTTARGETVALUE" value = "btnLogin_click">
<input type="hidden" name = "return_to_erro" value = "/miolo26/html/login_portal/">
    <!--END CONTENT-->
    
    <!--FOOTER-->
    <div class="footer"><img src="images/marca.png" width="120" height="90" alt="Solis" longdesc="http://www.solis.com.br" />
    <!--LOGIN BUTTON--><input  name="btnLogin" id="btnLogin" type="submit" class="button" value="Enviar" />
    
</form>
<!--END LOGIN FORM-->
</div>
        </div>
</div>
</div>

<div class="back">
    
</div>
</body>


<!--GRADIENT--><!--END GRADIENT-->


</html>
